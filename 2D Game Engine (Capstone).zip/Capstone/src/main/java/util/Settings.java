package util;

public class Settings {
    public static float GRID_WIDTH = 0.25f;
    public static float GRID_HEIGHT = 0.25f;
}
